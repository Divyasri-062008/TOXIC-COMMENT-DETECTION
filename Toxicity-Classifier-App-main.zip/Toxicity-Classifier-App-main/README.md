# Toxicity-Classifier-App
This is the official repo of "Toxicity Classifier App" from the AI Anytime YouTube video. This takes text as an input and classify that between toxic and non-toxic.
